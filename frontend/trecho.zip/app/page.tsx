"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { Auth } from "@/src/service/auth.service";

export default function Splash() {
  const router = useRouter();

  useEffect(() => {
    async function verificar() {
      const autenticado = await Auth.isAuthenticated();

      if (autenticado) {
        router.replace("/home");
      } else {
        router.replace("/auth/login");
      }
    }

    verificar();
  }, [router]);

  return null;
}