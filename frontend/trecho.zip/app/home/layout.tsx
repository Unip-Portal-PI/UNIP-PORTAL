import Navbar from "@/app/components/navbar";
import { LoadingProvider } from "@/app/components/LoadingContext";
import { FotoPerfilProvider } from "@/src/context/FotoPerfilContext";
import { cookies } from "next/headers";
import { API_BASE_URL } from "@/src/service/api-base-url";

async function getMatricula() {
  const cookieStore = await cookies();
  const token = cookieStore.get("token")?.value;

  if (!token) return "";

  try {
    const response = await fetch(`${API_BASE_URL}/auth/me`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
      cache: "no-store",
    });

    if (!response.ok) return "";

    const user = await response.json();
    return user?.matricula ?? "";
  } catch {
    return "";
  }
}

export default async function HomeLayout({ children }: { children: React.ReactNode }) {
  const matricula = await getMatricula();

  return (
    <LoadingProvider>
      <FotoPerfilProvider matricula={matricula}>
        <Navbar />
        {children}
      </FotoPerfilProvider>
    </LoadingProvider>
  );
}