"use client";

import { useMemo, useState } from "react";
import { LucideIcon, Eye, EyeOff, ChevronDown } from "lucide-react";
import { BLOCKED_TERMS } from "@/src/data/termsBlockMock";

interface InputProps {
  label: string;
  type: string;
  placeholder: string;
  id: string;
  Icon?: LucideIcon;
  erro?: boolean;
  defaultValue?: string;
  autoComplete?: string;
  required?: boolean;
}

interface SelectProps {
  label: string;
  id: string;
  placeholder: string;
  options: string[];
  Icon?: LucideIcon;
  erro?: boolean;
  required?: boolean;
}

function formatTelefone(value: string): string {
  const nums = value.replace(/\D/g, "").slice(0, 11);
  if (nums.length === 0) return "";
  if (nums.length <= 2) return `(${nums}`;
  if (nums.length <= 6) return `(${nums.slice(0, 2)}) ${nums.slice(2)}`;
  if (nums.length <= 10) return `(${nums.slice(0, 2)}) ${nums.slice(2, 6)}-${nums.slice(6)}`;
  return `(${nums.slice(0, 2)}) ${nums.slice(2, 7)}-${nums.slice(7)}`;
}

function formatMatricula(value: string): string {
  const cleaned = value.toUpperCase().replace(/[^A-Z0-9]/g, "");
  const letters = cleaned.replace(/[^A-Z]/g, "").slice(0, 2);
  const numbers = cleaned.replace(/\D/g, "").slice(0, 8);
  return `${letters}${numbers}`;
}

function normalizeText(value: string): string {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();
}

function containsBlockedTerm(value: string): boolean {
  const normalized = normalizeText(value);
  return BLOCKED_TERMS.some((term) => normalized.includes(normalizeText(term)));
}

export function InputCad({
  label,
  type,
  placeholder,
  id,
  Icon,
  erro,
  defaultValue,
  autoComplete,
  required = false,
}: InputProps) {
  const [showPassword, setShowPassword] = useState(false);
  const [telValue, setTelValue] = useState("");
  const [textValue, setTextValue] = useState(defaultValue ?? "");
  const [isFocused, setIsFocused] = useState(false);

  const isPassword = type === "password";
  const isTel = type === "tel";
  const isMatricula = id === "matricula";
  const isRestrictedField = id === "nome" || id === "apelido" || id === "email";

  const inputType = isPassword ? (showPassword ? "text" : "password") : type;

  const blockedValue = useMemo(() => {
    if (!isRestrictedField) return false;
    return containsBlockedTerm(textValue);
  }, [isRestrictedField, textValue]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value;

    if (isTel) {
      const formatted = formatTelefone(value);
      setTelValue(formatted);
      return;
    }

    if (isMatricula) {
      value = formatMatricula(value);
    }

    if (isPassword) {
      value = value.slice(0, 48);
    }

    setTextValue(value);
  };

  const currentValue = isTel ? telValue : textValue;

  return (
    <div className="flex flex-col gap-1 w-full">
      <label htmlFor={id} className="font-bold text-sm text-slate-800 dark:text-slate-200">
        {label} {required && <span className="text-red-500">*</span>}
      </label>

      <div className="relative flex items-center">
        {Icon && (
          <Icon className="absolute left-3 text-[#4D4D4D] dark:text-slate-400 w-4 h-4" />
        )}

        <input
          id={id}
          name={id}
          type={inputType}
          placeholder={placeholder}
          autoComplete={autoComplete}
          value={currentValue}
          onChange={handleChange}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          inputMode={isTel ? "numeric" : undefined}
          maxLength={isPassword ? 48 : isMatricula ? 10 : undefined}
          pattern={isMatricula ? "[A-Za-z]{2}[0-9]{8}" : undefined}
          title={isMatricula ? "A matrícula deve conter 2 letras e 8 números. Ex: PI20100333" : undefined}
          required={required}
          className={`w-full border rounded-md p-2 text-sm outline-none transition-colors
            ${Icon ? "pl-9" : "pl-3"}
            ${isPassword ? "pr-10" : "pr-3"}
            ${erro || blockedValue
              ? "border-red-400 bg-red-50 dark:bg-red-950 dark:border-red-600 focus:border-red-500 text-[#4D4D4D] dark:text-red-200 placeholder:text-red-300"
              : "border-slate-300 dark:border-[#505050] bg-blue-100 dark:bg-[#424242] focus:border-blue-500 dark:focus:border-blue-400 text-[#4D4D4D] dark:text-slate-200 placeholder:text-slate-400 dark:placeholder:text-[#888888]"
            }`}
        />

        {isPassword && (
          <button
            type="button"
            onClick={() => setShowPassword((v) => !v)}
            className="absolute right-3 text-slate-400 hover:text-slate-600 dark:text-slate-500 dark:hover:text-slate-300 transition-colors"
          >
            {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </button>
        )}
      </div>

      {isMatricula && currentValue.length > 0 && !/^[A-Z]{2}\d{8}$/.test(currentValue) && (
        <span className="text-xs text-red-500">
          A matrícula deve seguir o padrão: 2 letras e 8 números. Ex: PI20100333
        </span>
      )}

      {isPassword && isFocused && (
        <span className="text-xs text-slate-500 dark:text-slate-400">
          A senha pode ter no máximo 48 caracteres.
        </span>
      )}

      {blockedValue && (
        <span className="text-xs text-red-500">
          Esse campo contém termo inadequado e não pode ser enviado.
        </span>
      )}
    </div>
  );
}

export function SelectCad({
  label,
  id,
  placeholder,
  options,
  Icon,
  erro,
  required = false,
}: SelectProps) {
  return (
    <div className="flex flex-col gap-1 w-full">
      <label htmlFor={id} className="font-bold text-sm text-slate-800 dark:text-slate-200">
        {label} {required && <span className="text-red-500">*</span>}
      </label>
      <div className="relative flex items-center">
        {Icon && (
          <Icon className="absolute left-3 text-[#4D4D4D] dark:text-slate-400 w-4 h-4 z-10 pointer-events-none" />
        )}
        <select
          id={id}
          name={id}
          defaultValue=""
          required={required}
          className={`w-full border rounded-md p-2 text-sm outline-none transition-colors appearance-none cursor-pointer
            ${Icon ? "pl-9" : "pl-3"} pr-9
            ${erro
              ? "border-red-400 bg-red-50 dark:bg-red-950 dark:border-red-600 focus:border-red-500 text-[#4D4D4D] dark:text-red-200"
              : "border-slate-300 dark:border-[#505050] bg-blue-100 dark:bg-[#424242] focus:border-blue-500 dark:focus:border-blue-400 text-[#4D4D4D] dark:text-slate-200"
            }`}
        >
          <option value="" disabled className="text-slate-400 dark:text-[#888888]">
            {placeholder}
          </option>
          {options.map((curso) => (
            <option key={curso} value={curso}>
              {curso}
            </option>
          ))}
        </select>
        <ChevronDown className="absolute right-3 text-[#4D4D4D] dark:text-slate-400 w-4 h-4 pointer-events-none" />
      </div>
    </div>
  );
}