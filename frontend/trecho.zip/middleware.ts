import { NextRequest, NextResponse } from "next/server";

const AUTH_PAGES = ["/auth/login", "/auth/cadastro"];
const HOME_PREFIX = "/home";

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  const token = request.cookies.get("token")?.value;
  const role = request.cookies.get("role")?.value;

  const isAuthPage = AUTH_PAGES.some((route) => pathname.startsWith(route));
  const isProtectedRoute = pathname.startsWith(HOME_PREFIX);

  // não logado tentando entrar em rota protegida
  if (isProtectedRoute && !token) {
    return NextResponse.redirect(new URL("/auth/login", request.url));
  }

  // logado tentando voltar para login/cadastro
  if (isAuthPage && token) {
    return NextResponse.redirect(new URL("/home", request.url));
  }

  // exemplo de role
  if (pathname.startsWith("/home/admin") && role !== "adm") {
    return NextResponse.redirect(new URL("/home", request.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/home/:path*", "/auth/login", "/auth/cadastro"],
};