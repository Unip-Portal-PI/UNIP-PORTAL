
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Auth } from "@/src/service/auth.service";

export default function PublicGuard({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [verificado, setVerificado] = useState(false);

  useEffect(() => {
    async function verificar() {
      const autenticado = await Auth.isAuthenticated();

      if (autenticado) {
        router.replace("/home");
        return;
      }

      setVerificado(true);
    }

    verificar();
  }, [router]);

  if (!verificado) return null;

  return <>{children}</>;
}