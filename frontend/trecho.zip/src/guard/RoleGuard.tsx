"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Auth } from "@/src/service/auth.service";
import { UserRole } from "@/src/types/user";

interface RoleGuardProps {
  allow: UserRole[];
  redirectTo?: string;
  children: React.ReactNode;
}

export default function RoleGuard({
  allow,
  redirectTo = "/home",
  children,
}: RoleGuardProps) {
  const router = useRouter();
  const [verificado, setVerificado] = useState(false);

  useEffect(() => {
    async function verificar() {
      const user = await Auth.getUser();

      if (!user) {
        router.replace("/auth/login");
        return;
      }

      if (!allow.includes(user.permission)) {
        router.replace(redirectTo);
        return;
      }

      setVerificado(true);
    }

    verificar();
  }, [allow, redirectTo, router]);

  if (!verificado) return null;

  return <>{children}</>;
}