import { ResultadoLogin, ResultadoPadraoAuth, UsuarioSessao } from "@/src/types/user";
import { API_BASE_URL } from "@/src/service/api-base-url";

interface RegisterPayload {
  matricula: string;
  nome: string;
  apelido: string;
  telefone: string;
  dataNascimento?: string;
  area: string;
  email: string;
  senha: string;
}

export const Auth = {
  async login(matricula: string, senha: string): Promise<ResultadoLogin> {
    try {
      const response = await fetch("/src/routes/login.routes", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ matricula, senha }),
      });

      const data = await response.json();

      return {
        sucesso: response.ok && !!data?.sucesso,
        mensagem: data?.mensagem ?? "",
        usuario: data?.usuario ?? null,
      };
    } catch {
      return {
        sucesso: false,
        mensagem: "Erro ao fazer login.",
      };
    }
  },

  async register(payload: RegisterPayload): Promise<ResultadoPadraoAuth> {
    try {
      const response = await fetch(`${API_BASE_URL}/auth/register`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });

      const data = await response.json().catch(() => null);

      return {
        sucesso: response.ok && !!data?.sucesso,
        mensagem: data?.mensagem ?? "",
      };
    } catch {
      return {
        sucesso: false,
        mensagem: "Erro ao cadastrar, tente novamente!",
      };
    }
  },

  async logout(): Promise<void> {
    await fetch("/auth/logout", {
      method: "POST",
    });
  },

  async getUser(): Promise<UsuarioSessao | null> {
    try {
      const response = await fetch("/api/auth/me", {
        method: "GET",
        cache: "no-store",
      });

      if (!response.ok) return null;

      const data = await response.json();
      return data?.usuario ?? null;
    } catch {
      return null;
    }
  },

  async isAuthenticated(): Promise<boolean> {
    try {
      const response = await fetch("/api/auth/me", {
        method: "GET",
        cache: "no-store",
      });

      return response.ok;
    } catch {
      return false;
    }
  },
};