"use client";

// app/components/PublicGuard.tsx

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Auth } from "@/app/lib/useAuth";

export default function PublicGuard({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [verificado, setVerificado] = useState(false);

  useEffect(() => {
    if (Auth.isAuthenticated()) {
      router.replace("/home");
    } else {
      setVerificado(true);
    }
  }, [router]);

  if (!verificado) return null;

  return <>{children}</>;
}
